//
//  ViewController.swift
//  PlistDemo
//
//  Created by Jony Singla on 04/01/17.
//  Copyright © 2017 Jony Singla. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    var tableData = [String]()
    var receipeTiming = [String]()
    var thumbnails = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let path = Bundle.main.path(forResource: "Receipe", ofType: "plist")!
        let dict = NSDictionary(contentsOfFile: path)
        let url = NSURL.fileURL(withPath: path)
        print(url)
        
        
        tableData = dict!.object(forKey: "RecipeName") as! [String]
        receipeTiming = dict!.object(forKey: "PrepTime") as! [String]
        thumbnails = dict!.object(forKey: "Thumbnail") as! [String]
        print(tableData)
        print(receipeTiming)
        print(thumbnails)

        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! CellTableViewCell
        let row = indexPath.row
        cell.labelMenuName.text = tableData[row]
        cell.labelTiming.text = receipeTiming[row]
        cell.imageView?.image = UIImage(named: thumbnails[row])
        
        // Configure the cell...
        
//        cell.imageView?.image = UIImage(named: tableData[indexPath.row])
        
        return cell
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

