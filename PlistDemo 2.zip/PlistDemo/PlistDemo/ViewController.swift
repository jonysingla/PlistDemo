//
//  ViewController.swift
//  PlistDemo
//
//  Created by Jony Singla on 04/01/17.
//  Copyright © 2017 Jony Singla. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    var tableData = [String]()
    var receipeTiming = [String]()
    var thumbnails = [String]()
    
    
    @IBOutlet weak var buttonSaveAction: UIButton!
    @IBOutlet weak var textField: UITextField!
    
    
    let path = Bundle.main.path(forResource: "Receipe", ofType: "plist")!
    var dictionary : NSMutableDictionary!
    let fileManager = FileManager.default
    
    var num   : String = "Hello"
    //    var label : UILabel!
    
    @IBOutlet weak var labelDisplayValue: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        dictionary = NSMutableDictionary(contentsOfFile: path)
        
//        let path = Bundle.main.path(forResource: "Receipe", ofType: "plist")!
//        let result = NSDictionary(contentsOfFile: path)
//        let url = NSURL.fileURL(withPath: path)
//        print(url)
        
   
//        var paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
//        var path = paths.appending("Receipe.plist")
////        var path = paths.stringByAppendingPathComponent("Receipe.plist")
//        var fileManager = FileManager.default
//        if (!(fileManager.fileExists(atPath: path)))
//        {
//            var bundle = Bundle.main.path(forResource: "Receipe", ofType: "plist")
//            fileManager.copyItem(atPath: bundle!, toPath: path)
////            fileManager.copyItemAtPath(bundle, toPath: path, error:nil)
//        }
//        data.setObject(object, forKey: "object")
//        data.writeToFile(path, atomically: true)
        
        tableData = ["\(dictionary!.object(forKey: "Num")!)"]
    
//        tableData = result!.object(forKey: "RecipeName") as! [String]
//        receipeTiming = result!.object(forKey: "PrepTime") as! [String]
//        thumbnails = result!.object(forKey: "Thumbnail") as! [String]
        print(tableData)
        print(receipeTiming)
        print(thumbnails)

        checkFile()
        buttonReadAction(self)

    }
    
    func checkFile() {
        
        if !fileManager.fileExists(atPath: path) {
            print("File not exist!")
            
            let srcPath = Bundle.main.path(forResource: "Receipe", ofType: "plist")
            
            do {
                //Copy the project plist file to the documents directory.
                try fileManager.copyItem(atPath: srcPath!, toPath: path)
            } catch {
                print("File copy error!")
            }
        }
    }
    
//    func btnGenerate() {
//        num = Int(arc4random()%100)
//        label.text = "\(num)"
////        write()
//        
//        dictionary = NSMutableDictionary(contentsOfFile: path)
//    }

    
    
    
    @IBAction func buttonDeleteAction(_ sender: Any) {
        
        print("btnDel")
        labelDisplayValue.text = ""
        do {
            try fileManager.removeItem(atPath: path)
        } catch {
            print("Unable to delete the plist file")
        }
    }
    
    @IBAction func buttonSaveAction(_ sender: Any) {
        
        dictionary.setValue(num, forKey: "Num")
        dictionary.write(toFile: path, atomically: true)
        print("write")
        
    }
    
    @IBAction func buttonReadAction(_ sender: Any) {
        labelDisplayValue.text = "\(dictionary!.object(forKey: "Num")!)"
        print(dictionary!.object(forKey: "Num")!)
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as! CellTableViewCell
        let row = indexPath.row
//        cell.labelMenuName.text = tableData[row]
//        cell.labelTiming.text = receipeTiming[row]
//        cell.imageView?.image = UIImage(named: thumbnails[row])
        
        cell.labelMenuName.text = tableData[row]
        
        // Configure the cell...
        
//        cell.imageView?.image = UIImage(named: tableData[indexPath.row])
        
        return cell
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

